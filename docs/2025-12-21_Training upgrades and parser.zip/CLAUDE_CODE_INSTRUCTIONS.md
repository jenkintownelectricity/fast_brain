# 🔬 HIVE215 Ultimate Document Parser - Claude Code Instructions

## Quick Start Commands

Run these in your Fast Brain repository:

```bash
# 1. Navigate to your Fast Brain directory
cd /path/to/fast-brain

# 2. Create the parser module directory
mkdir -p app/parser

# 3. Install dependencies
pip install PyMuPDF python-docx python-pptx openpyxl html2text beautifulsoup4 lxml httpx pyyaml toml --break-system-packages
```

---

## File Structure

After setup, your structure should look like:

```
fast-brain/
├── app/
│   ├── parser/
│   │   ├── __init__.py
│   │   ├── universal_parser.py      # Main parser (70+ file types)
│   │   ├── data_manager.py          # Extraction & storage manager
│   │   └── routes.py                # API endpoints
│   └── ...
├── templates/
│   └── components/
│       └── data_manager.html        # UI component
└── ...
```

---

## Step 1: Create Parser Module

```bash
# Create the directory
mkdir -p app/parser

# Create __init__.py
cat > app/parser/__init__.py << 'EOF'
from .universal_parser import UniversalParser, FILE_TYPES, ALLOWED_EXTENSIONS
from .data_manager import DataExtractionManager
from .routes import parser_bp

__all__ = ['UniversalParser', 'DataExtractionManager', 'parser_bp', 'FILE_TYPES', 'ALLOWED_EXTENSIONS']
EOF
```

---

## Step 2: Run Database Migration

```bash
# Connect to your Supabase and run this SQL
```

```sql
-- Extracted Data Table (stores parsed content)
CREATE TABLE IF NOT EXISTS fb_extracted_data (
    id TEXT PRIMARY KEY,
    skill_id TEXT NOT NULL,
    content_type TEXT DEFAULT 'qa_pair',
    user_input TEXT NOT NULL,
    assistant_response TEXT NOT NULL,
    raw_content TEXT,
    source_filename TEXT,
    source_type TEXT,
    category TEXT DEFAULT 'general',
    tags TEXT[] DEFAULT '{}',
    importance_score REAL DEFAULT 50,
    confidence REAL DEFAULT 0.8,
    tokens INTEGER DEFAULT 0,
    is_approved BOOLEAN DEFAULT false,
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'
);

-- Indexes for fast queries
CREATE INDEX IF NOT EXISTS idx_extracted_skill ON fb_extracted_data(skill_id);
CREATE INDEX IF NOT EXISTS idx_extracted_category ON fb_extracted_data(category);
CREATE INDEX IF NOT EXISTS idx_extracted_importance ON fb_extracted_data(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_extracted_approved ON fb_extracted_data(is_approved);
CREATE INDEX IF NOT EXISTS idx_extracted_archived ON fb_extracted_data(is_archived);
CREATE INDEX IF NOT EXISTS idx_extracted_tags ON fb_extracted_data USING GIN(tags);
```

---

## Step 3: Register Blueprint in Your App

Add to your main Flask app (e.g., `unified_dashboard.py` or `app.py`):

```python
# At the top with other imports
from app.parser import parser_bp

# After app = Flask(__name__)
app.register_blueprint(parser_bp)
```

---

## Step 4: Set Environment Variables

```bash
# Add to your .env or Railway environment
GROQ_API_KEY=your_groq_api_key
OPENAI_API_KEY=your_openai_api_key  # For Whisper audio transcription
```

---

## Step 5: Add UI to Dashboard

Add this button to your Training section HTML:

```html
<!-- Add this button near your other training buttons -->
<button type="button" class="btn-parse-docs" onclick="openDocumentParserModal()">
    📄 Parse Documents
</button>

<!-- Add Data Manager Tab -->
<div class="tab-btn" onclick="showTab('dataManager')">📊 Extracted Data</div>
```

---

## API Endpoints Reference

Once deployed, you'll have these endpoints:

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/parser/supported-types` | List all 70+ supported formats |
| POST | `/api/parser/upload` | Upload & extract data from files |
| GET | `/api/parser/data/<skill_id>` | Get extracted data with filters |
| POST | `/api/parser/data/<skill_id>/bulk` | Bulk approve/tag/delete |
| GET | `/api/parser/data/<skill_id>/stats` | Get statistics |

---

## Testing

```bash
# Test file upload
curl -X POST http://localhost:5000/api/parser/upload \
  -F "files[]=@test.pdf" \
  -F "skill_id=your-skill-id"

# Get supported types
curl http://localhost:5000/api/parser/supported-types

# Get extracted data
curl "http://localhost:5000/api/parser/data/your-skill-id?page=1&per_page=50"
```

---

## Supported File Types (70+)

### Documents
- PDF, DOCX, DOC, RTF, ODT, Pages

### Spreadsheets  
- XLSX, XLS, CSV, TSV, ODS

### Presentations
- PPTX, PPT, ODP, Keynote

### Text & Code
- TXT, MD, RST, LOG
- PY, JS, TS, Java, C, C++, C#, Go, Rust, Ruby, PHP, SQL, Shell, Bash

### Data & Config
- JSON, JSONL, XML, YAML, YML, TOML, INI, ENV

### Web
- HTML, HTM, XHTML, CSS, SCSS, LESS

### Email
- EML, MSG, MBOX

### eBooks
- EPUB, MOBI

### Images (OCR via Vision)
- PNG, JPG, JPEG, GIF, WebP, BMP, TIFF, TIF, SVG, HEIC

### Audio (Whisper Transcription)
- MP3, WAV, M4A, OGG, FLAC, AAC, WMA

### Video (Audio Extraction + Transcription)
- MP4, MKV, AVI, MOV, WMV, WebM, FLV

### Archives (Recursive Extraction)
- ZIP, TAR, GZ, TGZ, RAR, 7Z

### Subtitles
- SRT, VTT, ASS, SSA

---

## Key Features

1. **Extract → Store → Delete** - Zero wasted storage
2. **AI-Powered Extraction** - Groq Llama finds Q&A pairs
3. **Importance Scoring** - Ranked 0-100
4. **Tag & Categorize** - Organize your data
5. **Bulk Actions** - Approve/archive many at once
6. **Move to Training** - One-click transfer

---

## Files Included

1. `ultimate_parser_v2.py` - Complete backend code
2. `data_manager_ui.html` - UI component for managing data
3. `CLAUDE_CODE_INSTRUCTIONS.md` - This file

---

## Troubleshooting

### Missing dependencies
```bash
pip install PyMuPDF python-docx python-pptx openpyxl html2text beautifulsoup4 lxml httpx pyyaml toml --break-system-packages
```

### OCR not working
Make sure `GROQ_API_KEY` is set and you have access to `llama-3.2-90b-vision-preview`

### Audio transcription not working
Make sure `OPENAI_API_KEY` is set for Whisper API access

### Database errors
Run the SQL migration in Step 2

---

## Next Steps After Integration

1. Upload some test documents
2. Review extracted Q&A pairs
3. Tag and categorize data
4. Approve high-quality items
5. Move approved items to training data
6. Train your skill with the new data!
