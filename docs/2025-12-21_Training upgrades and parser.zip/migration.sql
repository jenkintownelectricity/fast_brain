-- ═══════════════════════════════════════════════════════════════════════════════
-- HIVE215 Document Parser - Database Migration
-- Run this in your Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════════════════════════

-- Extracted Data Table (stores parsed content)
CREATE TABLE IF NOT EXISTS fb_extracted_data (
    id TEXT PRIMARY KEY,
    skill_id TEXT NOT NULL,
    content_type TEXT DEFAULT 'qa_pair',
    user_input TEXT NOT NULL,
    assistant_response TEXT NOT NULL,
    raw_content TEXT,
    source_filename TEXT,
    source_type TEXT,
    category TEXT DEFAULT 'general',
    tags TEXT[] DEFAULT '{}',
    importance_score REAL DEFAULT 50,
    confidence REAL DEFAULT 0.8,
    tokens INTEGER DEFAULT 0,
    is_approved BOOLEAN DEFAULT false,
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'
);

-- Indexes for fast queries
CREATE INDEX IF NOT EXISTS idx_extracted_skill ON fb_extracted_data(skill_id);
CREATE INDEX IF NOT EXISTS idx_extracted_category ON fb_extracted_data(category);
CREATE INDEX IF NOT EXISTS idx_extracted_importance ON fb_extracted_data(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_extracted_approved ON fb_extracted_data(is_approved);
CREATE INDEX IF NOT EXISTS idx_extracted_archived ON fb_extracted_data(is_archived);
CREATE INDEX IF NOT EXISTS idx_extracted_tags ON fb_extracted_data USING GIN(tags);
CREATE INDEX IF NOT EXISTS idx_extracted_created ON fb_extracted_data(created_at DESC);

-- Full text search index (optional but recommended)
CREATE INDEX IF NOT EXISTS idx_extracted_search ON fb_extracted_data 
    USING GIN(to_tsvector('english', user_input || ' ' || assistant_response));

-- ═══════════════════════════════════════════════════════════════════════════════
-- VERIFICATION
-- ═══════════════════════════════════════════════════════════════════════════════

-- Check table was created
SELECT 'fb_extracted_data table created successfully!' as status
WHERE EXISTS (SELECT FROM pg_tables WHERE tablename = 'fb_extracted_data');
