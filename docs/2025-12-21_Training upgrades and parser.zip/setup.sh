#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# HIVE215 Document Parser - Setup Script
# Run each section step by step in Claude Code
# ═══════════════════════════════════════════════════════════════════════════════

echo "🔬 HIVE215 Document Parser Setup"
echo "================================="

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Install Dependencies
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "📦 Step 1: Installing dependencies..."
pip install PyMuPDF python-docx python-pptx openpyxl html2text beautifulsoup4 lxml httpx pyyaml toml --break-system-packages

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2: Create Parser Directory
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "📁 Step 2: Creating parser directory..."
mkdir -p app/parser

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3: Copy Files
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "📋 Step 3: Copy the following files to app/parser/"
echo "   - __init__.py"
echo "   - universal_parser.py"
echo "   - data_manager.py"
echo "   - routes.py"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4: Register Blueprint
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "🔌 Step 4: Add to your main Flask app:"
echo ""
echo "   from app.parser import parser_bp"
echo "   app.register_blueprint(parser_bp)"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5: Run Migration
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "🗄️ Step 5: Run migration.sql in Supabase SQL Editor"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6: Set Environment Variables
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "🔐 Step 6: Set environment variables:"
echo "   GROQ_API_KEY=your_groq_api_key"
echo "   OPENAI_API_KEY=your_openai_api_key  (for Whisper)"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 7: Test
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "🧪 Step 7: Test the API:"
echo "   curl http://localhost:5000/api/parser/supported-types"

echo ""
echo "✅ Setup complete!"
